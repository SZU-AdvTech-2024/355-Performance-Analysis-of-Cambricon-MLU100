#include "ThreadPool.h"
#include <vector>
#include <iostream>
#include <opencv2/opencv.hpp>
#include "../../src/readimage/Shape.hpp"
int main(){
    ThreadPool pool(4);
    std::vector<std::future<std::vector<float>>> results;
    std::vector<std::string> image_vector;
    // Shape shape
    std::string path = "../lib/ThreadPool/pic/cat0.png";
    image_vector.push_back(path);
    image_vector.push_back(path);

    for(int i = 0; i < image_vector.size(); ++i){
        results.emplace_back(pool.enqueue([i]{
            std::vector<float> ii;
            std::cout << "hello" << std::endl;
            return ii;
        }));
    }

//    cv::Mat image = cv::imread(path, cv::IMREAD_COLOR);
//    if(image.empty()){
//        std::cerr << "file path error" << std::endl;
//        return  -1;
//    }
////    cv::namedWindow("Display Image", cv::WINDOW_AUTOSIZE);
//    cv::imshow("Display image", image);
//    cv::waitKey(0);
}